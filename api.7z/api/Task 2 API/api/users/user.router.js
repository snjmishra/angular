const { createUser,
getUserByUserId,
getUsers,
deleteUsers,
login,
updateUsers} =  require("./user.controller");
const router = require("express").Router();
const { checktoken } = require("../../auth/token_validation");

router.post("/",createUser);
router.get("/", getUsers);
router.get("/:id",  getUserByUserId);
router.patch("/",checktoken, updateUsers);
router.delete("/",checktoken, deleteUsers);
router.post("/login", login);

module.exports = router;