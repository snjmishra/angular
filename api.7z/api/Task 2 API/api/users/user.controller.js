const { create,
getUserByUserId,
getUsers,
updateUser,
deleteUser,
getUserByUserEmail
 } = require("./user.service");

const { genSaltSync, hashSync , compareSync} = require("bcrypt");
const { sign } = require("jsonwebtoken");
const { json } = require("express");

module.exports = {
    createUser: (req, res) => {
        const body = req.body;
        const salt = genSaltSync(10);
        body.password = hashSync(body.password, salt);
        create(body, (err, results) => {
            if (err) {
                console.log(err);
                return res.status(500).json({
                    success: 0,
                    mesaage: "Database Connection error"
                });
            }
            return res.status(200).json({
                success: 1,
                data: results
            });
        });
    },
    getUserByUserId: (req, res) => {
        const id = req.params.id;
        getUserByUserId(id, (err, results) => {
           if(err){
            console.log(err);
            return;
           }
           if(!results){
            return res.json({
                success: 0,
                message: "Record Not Found!"
            });
           }else{
            return res.json({
                success: 1,
                data: results
            })
           }
        });
    },
    getUsers: (req, res) => {
        getUsers((err, results) => {
            if (err) {
                console.log(err);
                return;
            }
            return res.json({
                success: 1,
                data: results
            })
        });
    },
    updateUsers: (req, res) => {
        const body = req.body;
        const salt = genSaltSync(10);
        body.password = hashSync(body.password, salt);
        updateUser(body, (err, results) => {
            if(err){
                console.log(err);
                return false;
            
                }
             if(!results){
                return res.json({
                    success: 0,
                    mesaage: "failed to update"
                })
             }   
                return res.json({
                    success: 1,
                    message: "Update Sucessfully"
                });
            
        });

    },
    deleteUsers: (req, res) => {
        const data = req.body;
        console.log(data);
        deleteUser(data, (err, results) => {
            if (err){
                console.log(err);
                return;
            }
            if(!results){
                return res.json({
                    success: 0,
                    mesaage: "Record Not Found"
                });
            }
                return res.json({
                    success: 1,
                    mesaage: "User Deleted Successfully"
                });
            
        })
    },
    login: (req, res) => {
      const body = req.body;
      getUserByUserEmail(body.email, (err, results) => {
        if(err){
            console.log(err);
        }
        if(!results){
            return res.json({
                success: 0,
                data: "Invalid email or Password Credentials"
            });
        }
            const result = compareSync(body.password, results.password);
            console.log(result);
            if (!result){
                results.password = undefined;
                const jsontoken = sign({result: results}, "que1234", {
                    expiresIn: "1h"
                });
                console.log(jsontoken)
                return res.json({
                  success: 1,
                  mesaage: "login Successfully",
                  token: jsontoken

                })
            }
               return res.json({
                success: 0,
                data: "Invalid email or password"
               });
            
        
      });
    }  
};

